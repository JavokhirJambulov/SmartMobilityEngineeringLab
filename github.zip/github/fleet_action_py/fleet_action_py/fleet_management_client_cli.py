import rclpy
from rclpy.action import ActionClient
from action_fleet_interfaces.action import FleetManagement  

def send_fleet_management_request(fleet_size):
    rclpy.init(args=None)
    client_node = rclpy.create_node('fleet_management_client')
    action_client = ActionClient(client_node, FleetManagement, 'fleet_management')

    goal_msg = FleetManagement.Goal()
    goal_msg.fleet_size = fleet_size

    action_client.wait_for_server()
    future = action_client.send_goal_async(goal_msg)
    
    rclpy.spin_until_future_complete(client_node, future)
    client_node.destroy_node()
    rclpy.shutdown()
    
    if future.result():
        action_result = future.result().result()
        return action_result.vehicle_routes
    else:
        return None

if __name__ == '__main__':
    fleet_size = int(input("Enter the fleet size: "))
    routes = send_fleet_management_request(fleet_size)
    
    if routes:
        print("Routes for the fleet:")
        for i, route in enumerate(routes):
            print(f"Vehicle {i+1}: {route}")
    else:
        print("Request failed or no routes received.")

