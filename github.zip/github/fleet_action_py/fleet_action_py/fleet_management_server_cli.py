import rclpy
from rclpy.action import ActionServer
from action_fleet_interfaces.action import FleetManagement  

def simple_route_generation(fleet_size):
    # Define task locations as a list of U.S. state names
    task_locations = ['Alabama', 'Alaska', 'Arizona', 'Arkansas', 'California', 'Colorado', 'Connecticut', 'Delaware', 'Florida', 'Georgia', 'Hawaii', 'Idaho', 'Illinois', 'Indiana', 'Iowa', 'Kansas', 'Kentucky', 'Louisiana', 'Maine', 'Maryland', 'Massachusetts', 'Michigan', 'Minnesota', 'Mississippi', 'Missouri', 'Montana', 'Nebraska', 'Nevada', 'New Hampshire', 'New Jersey', 'New Mexico', 'New York', 'North Carolina', 'North Dakota', 'Ohio', 'Oklahoma', 'Oregon', 'Pennsylvania', 'Rhode Island', 'South Carolina', 'South Dakota', 'Tennessee', 'Texas', 'Utah', 'Vermont', 'Virginia', 'Washington', 'West Virginia', 'Wisconsin', 'Wyoming']

    routes = {}
    num_tasks = len(task_locations)

    for i in range(fleet_size):
        routes[f'Vehicle_{i+1}'] = []

    for i, location in enumerate(task_locations):
        vehicle = f'Vehicle_{i % fleet_size + 1}'
        routes[vehicle].append(location)

    return routes

class FleetManagementServer:
    def __init__(self):
        self.node = rclpy.create_node('fleet_management_server')
        self.action_server = ActionServer(
            self.node,
            FleetManagement,
            'fleet_management',
            self.execute_callback
        )

    async def execute_callback(self, goal_handle):
        self.node.get_logger().info('Received fleet management request')
        
        # Extract the fleet size from the goal
        fleet_size = goal_handle.request.fleet_size
        
        # Generate routes using the simple_route_generation function
        vehicle_routes = simple_route_generation(fleet_size)
        
        # Return the calculated routes as the Action Result
        result = FleetManagement.Result()
        result.vehicle_routes = vehicle_routes
        
        # Publish feedback (completion percentage)
        feedback_msg = FleetManagement.Feedback()
        for i in range(1, fleet_size + 1):
            feedback_msg.completion_percentage = i / fleet_size
            goal_handle.publish_feedback(feedback_msg)
        
        goal_handle.succeed(result)
        self.node.get_logger().info('Fleet management completed successfully')

def main(args=None):
    rclpy.init(args=args)
    server = FleetManagementServer()
    rclpy.spin(server.node)
    server.node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

